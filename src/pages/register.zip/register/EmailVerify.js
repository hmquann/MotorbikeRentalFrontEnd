import React from "react";

const EmailVerify = () => {
  return <div></div>;
};

export default EmailVerify;
